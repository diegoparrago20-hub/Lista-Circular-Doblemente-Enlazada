/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public record Boleto(
        String noTicket,   // Clave primaria
        String estado,
        String fecha,      // Formato "dd/MM/yyyy" igual que la act pasada
        String clase,
        double precio) {

    public Boleto {
        if (noTicket == null || noTicket.trim().isEmpty()) {
            throw new IllegalArgumentException("El número de ticket es obligatorio.");
        }
        if (estado == null || estado.trim().isEmpty()) {
            throw new IllegalArgumentException("El estado no puede estar vacío.");
        }
        if (fecha == null || !fecha.matches("\\d{2}/\\d{2}/\\d{4}")) {
            throw new IllegalArgumentException("La fecha debe tener el formato dd/MM/yyyy.");
        }
        if (clase == null || clase.trim().isEmpty()) {
            throw new IllegalArgumentException("La clase del boleto es obligatoria.");
        }
        if (precio <= 0) {
            throw new IllegalArgumentException("El precio del boleto debe ser mayor a $0.0.");
        }
    }

    @Override
    public String toString() {
        return "==========================================\n" +
               "          DETALLES DEL BOLETO             \n" +
               "==========================================\n" +
               "• Número de Ticket  : " + noTicket + "\n" +
               "• Clase             : " + clase + "\n" +
               "• Precio            : $" + String.format("%.2f", precio) + "\n" +
               "• Fecha             : " + fecha + "\n" +
               "• Estado            : " + estado + "\n" +
               "==========================================";
    }
}//Final
