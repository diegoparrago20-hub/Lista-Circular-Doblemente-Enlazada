/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public class NodoC {
    private Boleto dato;
    private NodoC siguiente;
    private NodoC anterior;

    public NodoC(Boleto dato) {
        this.dato = dato;
        this.siguiente = this;
        this.anterior = this;
    }

    public Boleto getDato() {
        return dato;
    }

    public void setDato(Boleto dato) {
        this.dato = dato;
    }

    public NodoC getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoC siguiente) {
        this.siguiente = siguiente;
    }

    public NodoC getAnterior() {
        return anterior;
    }

    public void setAnterior(NodoC anterior) {
        this.anterior = anterior;
    }

    @Override
    public String toString() {
        return dato.toString();
    }
}//Final
