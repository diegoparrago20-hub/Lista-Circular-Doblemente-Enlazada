/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class TDAListaCircular {
    private NodoC primero;
    private NodoC ultimo;
    private int tamaño;
    
    public TDAListaCircular() {
        this.primero = null;
        this.ultimo = null;
        this.tamaño = 0;
    }
    
// *Operaciones de Inserción (insertar):
    // Insertar al principio:
    public void insertarPrincipio(Boleto dato) {
        NodoC nuevo = new NodoC(dato);
        if (estaVacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(primero);
            nuevo.setAnterior(ultimo);
            primero.setAnterior(nuevo);
            ultimo.setSiguiente(nuevo);
            primero = nuevo;
        }
        tamaño++;
    }
    // Insertar al final: 
    public void insertarFinal(Boleto dato) {
        NodoC nuevo = new NodoC(dato);
        if (estaVacia()) {
            primero = nuevo;
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(primero);
            nuevo.setAnterior(ultimo);
            ultimo.setSiguiente(nuevo);
            primero.setAnterior(nuevo);
            ultimo = nuevo;
        }
        tamaño++;
    }
    // Insertar por posición: 
    public void insertarPosicion(Boleto dato, int posicion) {
        if (posicion < 0 || posicion > tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango. Válida: 1 a " + tamaño);
        }
        if (posicion == 0) { // si esta vacia
            insertarPrincipio(dato);
        } else if (posicion == tamaño) { //lo mete en el tope/final
            insertarFinal(dato);
        } else { // y este busca si hay muchos elementos
            NodoC nuevo = new NodoC(dato);
            NodoC aux = primero;
            for (int i = 0; i < posicion - 1; i++) {
                aux = aux.getSiguiente();
            }
            // aux es el nodo anterior a la posición
            NodoC siguiente = aux.getSiguiente();

            nuevo.setSiguiente(siguiente);
            nuevo.setAnterior(aux);
            aux.setSiguiente(nuevo);
            siguiente.setAnterior(nuevo);
            tamaño++;
        }
    }
// *Operaciones de Remoción (remover):
    // Remover al principio: 
    public Boleto removerPrincipio() {
        if (estaVacia()) {
            return null;
        }
        Boleto dato = primero.getDato();
        if (tamaño == 1) {
            primero = null;
            ultimo = null;
        } else {
            NodoC nuevoPrimero = primero.getSiguiente();
            nuevoPrimero.setAnterior(ultimo);
            ultimo.setSiguiente(nuevoPrimero);
            primero = nuevoPrimero;
        }
        tamaño--;
        return dato;
    }
    // Remover al final:
    public Boleto removerFinal() {
        if (estaVacia()) {
            return null;
        }
        Boleto dato = ultimo.getDato();
        if (tamaño == 1) {
            primero = null;
            ultimo = null;
        } else {
            NodoC nuevoUltimo = ultimo.getAnterior();
            nuevoUltimo.setSiguiente(primero);
            primero.setAnterior(nuevoUltimo);
            ultimo = nuevoUltimo;
        }
        tamaño--;
        return dato;
    }
    // Remover por posición:  
    public Boleto removerPosicion(int posicion) {
        if (estaVacia()) {
            return null;
        }
        if (posicion < 0 || posicion >= tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango. Válida: 0 a " + (tamaño - 1));
        }
        if (posicion == 0) {
            return removerPrincipio();
        }
        if (posicion == tamaño - 1) {
            return removerFinal();
        }

        NodoC aux = primero;
        for (int i = 0; i < posicion; i++) {
            aux = aux.getSiguiente();
        }
        NodoC anterior = aux.getAnterior();
        NodoC siguiente = aux.getSiguiente();

        anterior.setSiguiente(siguiente);
        siguiente.setAnterior(anterior);
        tamaño--;
        return aux.getDato();
    }

// *Operaciones de Visualización / Muestra (mostrar):
    // Mostrar al principio:
    public Boleto mostrarPrincipio() {
        return (primero == null) ? null : primero.getDato();
    }
    // Mostrar al final
    public Boleto mostrarFinal() {
        return (ultimo == null) ? null : ultimo.getDato();
    }
    // Mostrar por posición:
    public Boleto mostrarPorPosicion(int posicion) {
        if (estaVacia()) {
            return null;
        }
        if (posicion < 0 || posicion >= tamaño) {
            throw new IndexOutOfBoundsException("Posición fuera de rango. Válida: 0 a " + (tamaño - 1));
        }
        NodoC aux = primero;
        for (int i = 0; i < posicion; i++) {
            aux = aux.getSiguiente();
        }
        return aux.getDato();
    }
// *Regla Obligatoria de Navegación Circular (siguiente / anterior):
    // Avanzar / Siguiente,
    public Boleto siguiente(int posicionActual) {
        if (estaVacia()) {
            return null;
        }
        if (posicionActual < 0 || posicionActual >= tamaño) {
            throw new IndexOutOfBoundsException("Posición actual fuera de rango.");
        }
        int siguientePos = (posicionActual + 1) % tamaño;
        return mostrarPorPosicion(siguientePos);
    }
    // Retroceder / Anterior
    public Boleto anterior(int posicionActual) {
        if (estaVacia()) {
            return null;
        }
        if (posicionActual < 0 || posicionActual >= tamaño) {
            throw new IndexOutOfBoundsException("Posición actual fuera de rango.");
        }
        int anteriorPos = (posicionActual - 1 + tamaño) % tamaño;
        return mostrarPorPosicion(anteriorPos);
        }
// *Operaciones de Búsqueda (buscar):
    // Buscar por valor:
    public Boleto buscarValor(String noTicket) {
        if (estaVacia() || noTicket == null) {
            return null;
        }
        NodoC aux = primero;
        for (int i = 0; i < tamaño; i++) {
            if (aux.getDato().noTicket().equals(noTicket)) {
                return aux.getDato();
            }
            aux = aux.getSiguiente();
        }
        return null;
    }
    // Buscar por posición:
    public Boleto buscarPosicion(int posicion) {
        return mostrarPorPosicion(posicion);
    }
// *Operaciones Auxiliares:
    // Vaciar y verificar estado:
    public boolean estaVacia() {
        return primero == null;
    }
    public int getTamaño() {
        return tamaño;
    }
    public void vaciar() {
        primero = null;
        ultimo = null;
        tamaño = 0;
    }
    
}//Final
